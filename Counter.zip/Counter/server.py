from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key ="sKey"
@app.route('/')
def index():
    if 'count' not in session:
        session['count'] = -1
    else:
        session['count']+=1
        print session['count']
    return render_template('index.html', count = session['count'])
@app.route('/click_2')
def click():

    session['count']+=1
    return redirect('/')
@app.route('/reset')
def reset():
    print "I have been clicked"
    session['count']=-1
    return redirect('/')

    
app.run(debug=True)